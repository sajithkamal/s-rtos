/*
 * GccApplication1.c
 *
 * Created: 9/9/2017 8:47:02 AM
 * Author : sajithkamal
 */ 


#include "srtos.h"

/* Target board 

   Teensy 2.0 ++
 */
int main(void)
{
	init_srtos();
}
